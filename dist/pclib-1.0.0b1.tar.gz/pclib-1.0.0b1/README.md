# PClib

PClib is a library that provides various functionalities for machine learning and data analysis. This README file provides an overview of the library and its example usage.

## Example usage

The `mnist/mnist_fc_*.ipynb` scripts are functional example/test scripts that demonstrate the usage of PClib. Please refer to these scripts for a practical understanding of the library's capabilities.

## PLEASE NOTE

Due to rapid iteration, much of the documentation/commenting is out of date/erroneous. Please bare with.